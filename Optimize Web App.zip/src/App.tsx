import { useState, useMemo } from "react";
import { Filter, RefreshCw, Package } from "lucide-react";
import { OrderCard, Order } from "./components/OrderCard";
import { OrderFilters } from "./components/OrderFilters";
import { StatusFilter } from "./components/StatusFilter";
import { SiteShopSelector } from "./components/SiteShopSelector";
import { Pagination } from "./components/Pagination";
import { OrderSort, SortField, SortDirection } from "./components/OrderSort";
import { SyncProgress } from "./components/SyncProgress";
import { CostStatusFilter, CostStatus } from "./components/CostStatusFilter";
import { ProductCostMappingManager, ProductCostMapping } from "./components/ProductCostMappingManager";
import { Checkbox } from "./components/ui/checkbox";
import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";

// Mock data for orders
const mockOrders: Order[] = [
  {
    id: "1",
    orderNumber: "2601069NC34KCU",
    username: "jaciaraoliveir4940",
    status: "pending",
    statusText: "待付款",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2026-01-05",
    shippingFee: 15.50,
    otherFees: 5.00,
    items: [
      {
        id: "1-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Cor de damasco",
        quantity: 1,
        price: 89.90,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
        sku: "1-2",
      },
      {
        id: "1-2",
        productName: "Mochila infantil colorida para escola",
        color: "Azul",
        quantity: 2,
        price: 45.50,
        image: "https://images.unsplash.com/photo-1577655197620-704858b270ac?w=400",
        sku: "1-3",
      }
    ]
  },
  {
    id: "2",
    orderNumber: "2601057YTE9PDY",
    username: "bianca_eloahnpg",
    status: "processing",
    statusText: "已收货",
    siteId: "shopee",
    shopId: "shop2",
    orderDate: "2026-01-06",
    shippingFee: 20.00,
    otherFees: 8.50,
    items: [
      {
        id: "2-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Cor de damasco",
        quantity: 1,
        price: 89.90,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
        sku: "2-1",
      },
      {
        id: "2-2",
        productName: "Mochila Mamãe Novo Estilo Mãe Para Bebê Grande Capacidade",
        color: "Rosa",
        quantity: 2,
        price: 95.00,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
        sku: "2-2",
      },
      {
        id: "2-3",
        productName: "Organizador de fraldas portátil",
        color: "Branco",
        quantity: 1,
        price: 35.80,
        image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400",
        sku: "2-3",
      }
    ]
  },
  {
    id: "3",
    orderNumber: "2601045JUKSH1N",
    username: "a.muticarleze",
    status: "shipped",
    statusText: "运出中",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2026-01-05",
    shippingFee: 12.80,
    otherFees: 3.20,
    items: [
      {
        id: "3-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Verde",
        quantity: 1,
        price: 89.90,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "3-2",
        productName: "Kit berço portátil de viagem",
        color: "Cinza",
        quantity: 1,
        price: 125.00,
        image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400",
      }
    ]
  },
  {
    id: "4",
    orderNumber: "2601044P04N9DB",
    username: "hayasam",
    status: "processing",
    statusText: "已收货",
    siteId: "amazon",
    shopId: "shop3",
    orderDate: "2026-01-04",
    shippingFee: 25.00,
    otherFees: 10.00,
    items: [
      {
        id: "4-1",
        productName: "Mochila Mamãe Novo Estilo Mãe Para Bebê Grande Capacidade Agasalho Multifuncional",
        color: "Arroz em pó",
        quantity: 1,
        price: 105.50,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "4-2",
        productName: "Trocador de fraldas dobrável",
        color: "Bege",
        quantity: 1,
        price: 68.00,
        image: "https://images.unsplash.com/photo-1555940280-66b7000c6981?w=400",
      },
      {
        id: "4-3",
        productName: "Porta mamadeira térmico",
        color: "Preto",
        quantity: 3,
        price: 28.50,
        image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=400",
      }
    ]
  },
  {
    id: "5",
    orderNumber: "2601042K3LMP8V",
    username: "maria.eduarda2345",
    status: "completed",
    statusText: "查看详情",
    siteId: "shopee",
    shopId: "shop2",
    orderDate: "2026-01-03",
    shippingFee: 8.50,
    otherFees: 2.00,
    items: [
      {
        id: "5-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Preto",
        quantity: 1,
        price: 89.90,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      }
    ]
  },
  {
    id: "6",
    orderNumber: "2601038LL2NP9C",
    username: "fernanda_costa88",
    status: "pending",
    statusText: "待付款",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2026-01-02",
    shippingFee: 22.00,
    otherFees: 7.50,
    items: [
      {
        id: "6-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Azul marinho",
        quantity: 2,
        price: 89.90,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "6-2",
        productName: "Cestinho organizador para carrinho",
        color: "Cinza claro",
        quantity: 1,
        price: 42.00,
        image: "https://images.unsplash.com/photo-1519181245277-cffeb31da2e3?w=400",
      },
      {
        id: "6-3",
        productName: "Capa de chuva para carrinho de bebê",
        color: "Transparente",
        quantity: 1,
        price: 25.80,
        image: "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400",
      },
      {
        id: "6-4",
        productName: "Mosquiteiro para carrinho",
        color: "Branco",
        quantity: 1,
        price: 18.90,
        image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400",
      }
    ]
  },
  {
    id: "7",
    orderNumber: "2601032ML9KH4T",
    username: "juliana_mendes01",
    status: "shipped",
    statusText: "运出中",
    siteId: "amazon",
    shopId: "shop4",
    orderDate: "2026-01-01",
    items: [
      {
        id: "7-1",
        productName: "Mochila Mamãe Novo Estilo Mãe Para Bebê Grande Capacidade Agasalho Multifuncional",
        color: "Cinza",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "7-2",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Preto",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "7-3",
        productName: "Mochila infantil colorida",
        color: "Amarelo",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1577655197620-704858b270ac?w=400",
      }
    ]
  },
  {
    id: "8",
    orderNumber: "2601028PP5RT6Y",
    username: "carla.silva99",
    status: "processing",
    statusText: "已收货",
    siteId: "shopee",
    shopId: "shop2",
    orderDate: "2025-12-31",
    items: [
      {
        id: "8-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Rosa",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "8-2",
        productName: "Necessaire organizadora de higiene",
        color: "Rosa claro",
        quantity: 2,
        image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=400",
      }
    ]
  },
  {
    id: "9",
    orderNumber: "2601021HH8VB3W",
    username: "amanda_rodrigues",
    status: "completed",
    statusText: "查看详情",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2025-12-30",
    items: [
      {
        id: "9-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Bege",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      }
    ]
  },
  {
    id: "10",
    orderNumber: "2601019MM2QP7L",
    username: "patricia_alves23",
    status: "pending",
    statusText: "待付款",
    siteId: "amazon",
    shopId: "shop3",
    orderDate: "2025-12-29",
    items: [
      {
        id: "10-1",
        productName: "Mochila Mamãe Novo Estilo Mãe Para Bebê Grande Capacidade Agasalho Multifuncional",
        color: "Verde escuro",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "10-2",
        productName: "Bolsa térmica para mamadeira dupla",
        color: "Verde água",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=400",
      },
      {
        id: "10-3",
        productName: "Mini kit primeiros socorros",
        color: "Vermelho",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1603398938378-e54eab446dde?w=400",
      }
    ]
  },
  {
    id: "11",
    orderNumber: "2601015NN9KL2M",
    username: "beatriz_santos77",
    status: "shipped",
    statusText: "运出中",
    siteId: "shopee",
    shopId: "shop5",
    orderDate: "2025-12-28",
    items: [
      {
        id: "11-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Vermelho",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "11-2",
        productName: "Almofada de amamentação ergonômica",
        color: "Azul bebê",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400",
      }
    ]
  },
  {
    id: "12",
    orderNumber: "2601012TT6WX8N",
    username: "roberta_lima55",
    status: "processing",
    statusText: "已收货",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2025-12-27",
    items: [
      {
        id: "12-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Cor de damasco",
        quantity: 2,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      }
    ]
  },
  {
    id: "13",
    orderNumber: "2601008VV3YZ5P",
    username: "lucas_pereira88",
    status: "completed",
    statusText: "查看详情",
    siteId: "amazon",
    shopId: "shop4",
    orderDate: "2025-12-26",
    items: [
      {
        id: "13-1",
        productName: "Mochila Mamãe Novo Estilo Mãe Para Bebê Grande Capacidade Agasalho Multifuncional",
        color: "Preto",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "13-2",
        productName: "Capa protetora para assento de carro",
        color: "Preto",
        quantity: 2,
        image: "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400",
      },
      {
        id: "13-3",
        productName: "Espelho retrovisor para bebê",
        color: "Preto",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1519181245277-cffeb31da2e3?w=400",
      }
    ]
  },
  {
    id: "14",
    orderNumber: "2601005QQ1AB9R",
    username: "isabela_gomes12",
    status: "pending",
    statusText: "待付款",
    siteId: "shopee",
    shopId: "shop2",
    orderDate: "2025-12-25",
    items: [
      {
        id: "14-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Marrom",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      }
    ]
  },
  {
    id: "15",
    orderNumber: "2601001RR7CD4S",
    username: "gabriela_martins34",
    status: "shipped",
    statusText: "运出中",
    siteId: "tiktok",
    shopId: "shop1",
    orderDate: "2025-12-24",
    items: [
      {
        id: "15-1",
        productName: "Bolsa de bebê de mãe portátil de grande capacidade",
        color: "Azul claro",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1677740785568-21a762413949?w=400",
      },
      {
        id: "15-2",
        productName: "Cesto de roupas dobráveis para bebê",
        color: "Listrado azul",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400",
      },
      {
        id: "15-3",
        productName: "Conjunto de panos de boca 10 unidades",
        color: "Multicolorido",
        quantity: 1,
        image: "https://images.unsplash.com/photo-1555940280-66b7000c6981?w=400",
      }
    ]
  }
];

// Site and Shop data
const sites = [
  { value: 'all', label: '全部站点' },
  { value: 'tiktok', label: 'TikTok Shop' },
  { value: 'shopee', label: 'Shopee' },
  { value: 'amazon', label: 'Amazon' },
];

const shops = [
  { value: 'shop1', label: 'TikTok旗舰店', siteId: 'tiktok' },
  { value: 'shop2', label: 'Shopee官方店', siteId: 'shopee' },
  { value: 'shop5', label: 'Shopee海外店', siteId: 'shopee' },
  { value: 'shop3', label: 'Amazon美国店', siteId: 'amazon' },
  { value: 'shop4', label: 'Amazon欧洲店', siteId: 'amazon' },
];

export default function App() {
  const [searchQuery, setSearchQuery] = useState("");
  const [dateRange, setDateRange] = useState("2025-12-30 至 2026-01-06");
  const [showFilters, setShowFilters] = useState(false);
  const [activeStatus, setActiveStatus] = useState("all");
  const [selectedSite, setSelectedSite] = useState("all");
  const [selectedShop, setSelectedShop] = useState("all");
  
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5; // 每页显示5个订单
  const [sortField, setSortField] = useState<SortField>('none');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [isSyncing, setIsSyncing] = useState(false);
  const [selectedOrders, setSelectedOrders] = useState<Set<string>>(new Set());
  const [costStatus, setCostStatus] = useState<CostStatus>('all');
  const [costMappings, setCostMappings] = useState<ProductCostMapping[]>([]);
  const [showMappingManager, setShowMappingManager] = useState(false);

  // Helper function to check if an order has cost recorded
  const hasOrderCostRecorded = (order: Order): boolean => {
    // Check if all items have both purchaseCost and domesticShippingCost
    return order.items.every(item => 
      (item.purchaseCost !== undefined && item.purchaseCost > 0) ||
      (item.domesticShippingCost !== undefined && item.domesticShippingCost > 0)
    );
  };

  // Calculate status counts based on current site/shop selection
  const statusCounts = useMemo(() => {
    let filteredByLocation = orders;
    
    // Filter by site
    if (selectedSite !== 'all') {
      filteredByLocation = filteredByLocation.filter(order => order.siteId === selectedSite);
    }
    
    // Filter by shop
    if (selectedShop !== 'all') {
      filteredByLocation = filteredByLocation.filter(order => order.shopId === selectedShop);
    }
    
    const counts: Record<string, number> = {
      all: filteredByLocation.length,
      pending: 0,
      processing: 0,
      shipped: 0,
      completed: 0,
    };
    
    filteredByLocation.forEach(order => {
      counts[order.status] = (counts[order.status] || 0) + 1;
    });
    
    return counts;
  }, [selectedSite, selectedShop, orders]);

  // Reset to page 1 when filters change
  useMemo(() => {
    setCurrentPage(1);
  }, [searchQuery, activeStatus, selectedSite, selectedShop, costStatus]);

  // Calculate cost status counts from the base filtered orders (before cost filter)
  const costStatusCounts = useMemo(() => {
    let baseFiltered = orders;
    
    // Apply same site/shop/status/search filters as main filter
    if (selectedSite !== 'all') {
      baseFiltered = baseFiltered.filter(order => order.siteId === selectedSite);
    }
    
    if (selectedShop !== 'all') {
      baseFiltered = baseFiltered.filter(order => order.shopId === selectedShop);
    }
    
    if (activeStatus !== 'all') {
      baseFiltered = baseFiltered.filter(order => order.status === activeStatus);
    }
    
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      baseFiltered = baseFiltered.filter(order => 
        order.orderNumber.toLowerCase().includes(query) ||
        order.statusText.toLowerCase().includes(query) ||
        order.items.some(item => item.productName.toLowerCase().includes(query))
      );
    }
    
    const recorded = baseFiltered.filter(order => hasOrderCostRecorded(order)).length;
    const unrecorded = baseFiltered.length - recorded;
    
    return {
      total: baseFiltered.length,
      recorded,
      unrecorded
    };
  }, [orders, selectedSite, selectedShop, activeStatus, searchQuery]);

  // Filter orders based on all criteria
  const filteredOrders = useMemo(() => {
    let filtered = orders;
    
    // Filter by site
    if (selectedSite !== 'all') {
      filtered = filtered.filter(order => order.siteId === selectedSite);
    }
    
    // Filter by shop
    if (selectedShop !== 'all') {
      filtered = filtered.filter(order => order.shopId === selectedShop);
    }
    
    // Filter by status
    if (activeStatus !== 'all') {
      filtered = filtered.filter(order => order.status === activeStatus);
    }

    // Filter by cost status
    if (costStatus !== 'all') {
      filtered = filtered.filter(order => {
        const hasCost = hasOrderCostRecorded(order);
        return costStatus === 'recorded' ? hasCost : !hasCost;
      });
    }
    
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(order => 
        order.orderNumber.toLowerCase().includes(query) ||
        order.statusText.toLowerCase().includes(query) ||
        order.items.some(item => item.productName.toLowerCase().includes(query))
      );
    }
    
    // Sort orders
    if (sortField !== 'none') {
      filtered = [...filtered].sort((a, b) => {
        let aValue = 0;
        let bValue = 0;
        
        if (sortField === 'productTotal') {
          // 商品总额
          aValue = a.items.reduce((sum, item) => sum + (item.price || 0) * item.quantity, 0);
          bValue = b.items.reduce((sum, item) => sum + (item.price || 0) * item.quantity, 0);
        } else if (sortField === 'purchaseCost') {
          // 采购总成本
          aValue = a.manualTotalCost !== undefined 
            ? a.manualTotalCost 
            : a.items.reduce((sum, item) => sum + ((item.purchaseCost || 0) + (item.domesticShippingCost || 0)) * item.quantity, 0);
          bValue = b.manualTotalCost !== undefined 
            ? b.manualTotalCost 
            : b.items.reduce((sum, item) => sum + ((item.purchaseCost || 0) + (item.domesticShippingCost || 0)) * item.quantity, 0);
        } else if (sortField === 'shippingFee') {
          // 预估运费总额
          aValue = a.shippingFee || 0;
          bValue = b.shippingFee || 0;
        } else if (sortField === 'otherFees') {
          // 费用
          aValue = a.otherFees || 0;
          bValue = b.otherFees || 0;
        } else if (sortField === 'revenue') {
          // 预估订单收入
          const aProductTotal = a.items.reduce((sum, item) => sum + (item.price || 0) * item.quantity, 0);
          const aTotalCost = a.manualTotalCost !== undefined 
            ? a.manualTotalCost 
            : a.items.reduce((sum, item) => sum + ((item.purchaseCost || 0) + (item.domesticShippingCost || 0)) * item.quantity, 0);
          aValue = aProductTotal - aTotalCost - (a.shippingFee || 0) - (a.otherFees || 0);
          
          const bProductTotal = b.items.reduce((sum, item) => sum + (item.price || 0) * item.quantity, 0);
          const bTotalCost = b.manualTotalCost !== undefined 
            ? b.manualTotalCost 
            : b.items.reduce((sum, item) => sum + ((item.purchaseCost || 0) + (item.domesticShippingCost || 0)) * item.quantity, 0);
          bValue = bProductTotal - bTotalCost - (b.shippingFee || 0) - (b.otherFees || 0);
        }
        
        if (sortDirection === 'asc') {
          return aValue - bValue;
        } else {
          return bValue - aValue;
        }
      });
    }
    
    return filtered;
  }, [searchQuery, activeStatus, selectedSite, selectedShop, orders, sortField, sortDirection, costStatus]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredOrders.length / itemsPerPage);
  const paginatedOrders = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredOrders.slice(startIndex, endIndex);
  }, [filteredOrders, currentPage, itemsPerPage]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewDetails = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    toast.success(`查看订单 ${order?.orderNumber} 详情`);
  };

  const handleItemCostUpdate = (orderId: string, itemId: string, purchaseCost: number, domesticShippingCost: number) => {
    setOrders(prevOrders => 
      prevOrders.map(order => {
        if (order.id === orderId) {
          return {
            ...order,
            items: order.items.map(item => 
              item.id === itemId
                ? { ...item, purchaseCost, domesticShippingCost }
                : item
            )
          };
        }
        return order;
      })
    );
  };

  const handleOrderTotalCostUpdate = (orderId: string, totalCost: number) => {
    setOrders(prevOrders => 
      prevOrders.map(order => 
        order.id === orderId 
          ? { ...order, manualTotalCost: totalCost }
          : order
      )
    );
  };

  const handleExport = () => {
    setIsSyncing(true);
  };

  const handleSyncComplete = () => {
    setIsSyncing(false);
    toast.success("订单已同步成功");
  };

  const handleDateRangeChange = (range: string) => {
    setDateRange(range);
    toast.success(`日期范围已更新: ${range}`);
  };

  const handleSortChange = (field: SortField) => {
    if (field === 'none') {
      setSortField('none');
      setSortDirection('desc');
    } else if (sortField === field) {
      // Toggle direction if clicking the same field
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // New field, default to descending
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleOrderSelection = (orderId: string, selected: boolean) => {
    setSelectedOrders(prev => {
      const newSet = new Set(prev);
      if (selected) {
        newSet.add(orderId);
      } else {
        newSet.delete(orderId);
      }
      return newSet;
    });
  };

  const handleSelectAll = (selected: boolean) => {
    if (selected) {
      setSelectedOrders(new Set(paginatedOrders.map(order => order.id)));
    } else {
      setSelectedOrders(new Set());
    }
  };

  const handleSyncSelected = () => {
    if (selectedOrders.size === 0) {
      toast.error("请先选择要同步的订单");
      return;
    }
    setIsSyncing(true);
  };

  const allSelected = paginatedOrders.length > 0 && paginatedOrders.every(order => selectedOrders.has(order.id));
  const someSelected = paginatedOrders.some(order => selectedOrders.has(order.id)) && !allSelected;

  const handleAddMapping = (mapping: Omit<ProductCostMapping, "id" | "createdAt">) => {
    const newMapping: ProductCostMapping = {
      ...mapping,
      id: `mapping-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setCostMappings(prev => [...prev, newMapping]);
    toast.success(`已添加商品成本映射: ${mapping.productName}`);
  };

  const handleDeleteMapping = (id: string) => {
    setCostMappings(prev => prev.filter(m => m.id !== id));
    toast.success("已删除成本映射");
  };

  const handleSaveMapping = (productId: string, productName: string, sku: string | undefined, siteId: string, shopId: string, purchaseCost: number, domesticShippingCost: number) => {
    const existingMapping = costMappings.find(
      m => m.productId === productId && m.siteId === siteId && m.shopId === shopId
    );
    
    if (existingMapping) {
      setCostMappings(prev =>
        prev.map(m =>
          m.id === existingMapping.id
            ? { ...m, purchaseCost, domesticShippingCost, sku }
            : m
        )
      );
      toast.success("已更新成本映射");
    } else {
      handleAddMapping({ productId, productName, sku, siteId, shopId, purchaseCost, domesticShippingCost });
    }
  };

  // Extract unique products from all orders
  const availableProducts = useMemo(() => {
    const productMap = new Map<string, { id: string; name: string; sku?: string }>();
    
    orders.forEach(order => {
      order.items.forEach(item => {
        if (!productMap.has(item.id)) {
          productMap.set(item.id, {
            id: item.id,
            name: item.productName,
            sku: item.sku,
          });
        }
      });
    });
    
    return Array.from(productMap.values());
  }, [orders]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster />
      <SyncProgress isVisible={isSyncing} onComplete={handleSyncComplete} />
      
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="mb-2">我的订单</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowMappingManager(true)}
              className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white border border-border rounded-lg hover:bg-muted transition-colors text-sm"
            >
              <Package className="w-4 h-4" />
              成本映射管理
            </button>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="sm:hidden p-2 hover:bg-muted rounded-lg transition-colors"
              aria-label="Toggle filters"
            >
              <Filter className="size-5" />
            </button>
          </div>
        </div>

        {/* Site and Shop Selector */}
        <div className="mb-6">
          <SiteShopSelector
            selectedSite={selectedSite}
            selectedShop={selectedShop}
            onSiteChange={setSelectedSite}
            onShopChange={setSelectedShop}
            sites={sites}
            shops={shops}
          />
        </div>

        {/* Filters */}
        <div className={`${showFilters ? 'block' : 'hidden'} sm:block`}>
          <OrderFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            dateRange={dateRange}
            onDateRangeChange={handleDateRangeChange}
            onExport={handleExport}
          />
          <StatusFilter
            activeStatus={activeStatus}
            onStatusChange={setActiveStatus}
            statusCounts={statusCounts}
          />
          <CostStatusFilter
            activeCostStatus={costStatus}
            onCostStatusChange={setCostStatus}
            costStatusCounts={costStatusCounts}
          />
          <OrderSort
            onSortChange={handleSortChange}
            sortField={sortField}
            sortDirection={sortDirection}
          />
        </div>

        {/* Order Count */}
        <div className="mb-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              {paginatedOrders.length > 0 && (
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={(checked) => handleSelectAll(checked === true)}
                    aria-label="全选"
                    className={someSelected && !allSelected ? "data-[state=checked]:bg-primary" : ""}
                  />
                  <span className="text-sm text-muted-foreground">全选</span>
                </div>
              )}
              
              <h2 className="text-sm text-muted-foreground">
                {searchQuery && (
                  <span>
                    搜索 "<span className="font-medium text-foreground">{searchQuery}</span>" 找到 {filteredOrders.length} 个结果
                  </span>
                )}
                {!searchQuery && (
                  <span>{filteredOrders.length} 订单</span>
                )}
                {selectedOrders.size > 0 && (
                  <span className="ml-2 text-primary">
                    (已选 {selectedOrders.size} 个)
                  </span>
                )}
              </h2>
            </div>
            
            <div className="flex items-center gap-2">
              {selectedOrders.size > 0 && (
                <button
                  onClick={handleSyncSelected}
                  className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm"
                >
                  <RefreshCw className="w-4 h-4" />
                  同步选中订单
                </button>
              )}
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="text-sm text-primary hover:underline"
                >
                  清除搜索
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="space-y-4">
          {paginatedOrders.length > 0 ? (
            paginatedOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                onViewDetails={handleViewDetails}
                onItemCostUpdate={handleItemCostUpdate}
                onOrderTotalCostUpdate={handleOrderTotalCostUpdate}
                isSelected={selectedOrders.has(order.id)}
                onSelectionChange={handleOrderSelection}
                costMappings={costMappings}
                onSaveMapping={handleSaveMapping}
              />
            ))
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border border-border">
              <p className="text-muted-foreground">未找到匹配的订单</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="mt-6">
          <Pagination 
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={filteredOrders.length}
            itemsPerPage={itemsPerPage}
            onPageChange={handlePageChange}
          />
        </div>
      </div>

      {/* Mapping Manager Modal */}
      {showMappingManager && (
        <ProductCostMappingManager
          mappings={costMappings}
          onAddMapping={handleAddMapping}
          onDeleteMapping={handleDeleteMapping}
          onClose={() => setShowMappingManager(false)}
          sites={sites}
          shops={shops}
          products={availableProducts}
          orders={orders}
        />
      )}
    </div>
  );
}