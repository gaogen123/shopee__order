import { Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar as CalendarComponent } from "./ui/calendar";
import { useState } from "react";

interface DateRangePickerProps {
  dateRange: string;
  onDateRangeChange: (range: string) => void;
}

export function DateRangePicker({ dateRange, onDateRangeChange }: DateRangePickerProps) {
  const [open, setOpen] = useState(false);
  const [startDate, setStartDate] = useState<Date | undefined>(new Date(2025, 11, 30)); // 2025-12-30
  const [endDate, setEndDate] = useState<Date | undefined>(new Date(2026, 0, 6)); // 2026-01-06
  const [selectingStart, setSelectingStart] = useState(true);

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;

    if (selectingStart) {
      setStartDate(date);
      setEndDate(undefined);
      setSelectingStart(false);
    } else {
      if (startDate && date < startDate) {
        // If end date is before start date, swap them
        setEndDate(startDate);
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      
      // Format and update the date range
      const start = startDate || date;
      const end = date >= (startDate || date) ? date : startDate;
      
      if (start && end) {
        const formattedRange = `${formatDate(start)} 至 ${formatDate(end)}`;
        onDateRangeChange(formattedRange);
        setOpen(false);
        setSelectingStart(true);
      }
    }
  };

  const formatDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const handleReset = () => {
    setSelectingStart(true);
    setStartDate(undefined);
    setEndDate(undefined);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className="flex items-center gap-2 whitespace-nowrap"
        >
          <Calendar className="size-4" />
          <span className="text-sm">{dateRange}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="end">
        <div className="p-3 border-b border-border">
          <p className="text-sm">
            {selectingStart ? (
              <span className="text-muted-foreground">选择开始日期</span>
            ) : (
              <span className="text-muted-foreground">选择结束日期</span>
            )}
          </p>
          {startDate && (
            <p className="text-sm mt-1">
              开始: {formatDate(startDate)}
              {endDate && ` - 结束: ${formatDate(endDate)}`}
            </p>
          )}
        </div>
        <CalendarComponent
          mode="single"
          selected={selectingStart ? startDate : endDate}
          onSelect={handleDateSelect}
          initialFocus
        />
        <div className="p-3 border-t border-border flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleReset}
            className="flex-1"
          >
            重置
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setOpen(false)}
            className="flex-1"
          >
            取消
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
