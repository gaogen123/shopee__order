
  # Optimize Web App

  This is a code bundle for Optimize Web App. The original project is available at https://www.figma.com/design/rxtsaTZGVZylFk1fwVT9at/Optimize-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  